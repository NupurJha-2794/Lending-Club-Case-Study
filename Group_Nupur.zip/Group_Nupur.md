```python
## import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
```


```python
import pandas as pd

file_path = 'C:\\Users\\GNQTB\\DocumentsP\\Python\\loan.csv'
loan_data = pd.read_csv(file_path)
```


```python
loan_data.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>member_id</th>
      <th>loan_amnt</th>
      <th>funded_amnt</th>
      <th>funded_amnt_inv</th>
      <th>term</th>
      <th>int_rate</th>
      <th>installment</th>
      <th>grade</th>
      <th>sub_grade</th>
      <th>...</th>
      <th>num_tl_90g_dpd_24m</th>
      <th>num_tl_op_past_12m</th>
      <th>pct_tl_nvr_dlq</th>
      <th>percent_bc_gt_75</th>
      <th>pub_rec_bankruptcies</th>
      <th>tax_liens</th>
      <th>tot_hi_cred_lim</th>
      <th>total_bal_ex_mort</th>
      <th>total_bc_limit</th>
      <th>total_il_high_credit_limit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1077501</td>
      <td>1296599</td>
      <td>5000</td>
      <td>5000</td>
      <td>4975.0</td>
      <td>36 months</td>
      <td>10.65%</td>
      <td>162.87</td>
      <td>B</td>
      <td>B2</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1077430</td>
      <td>1314167</td>
      <td>2500</td>
      <td>2500</td>
      <td>2500.0</td>
      <td>60 months</td>
      <td>15.27%</td>
      <td>59.83</td>
      <td>C</td>
      <td>C4</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1077175</td>
      <td>1313524</td>
      <td>2400</td>
      <td>2400</td>
      <td>2400.0</td>
      <td>36 months</td>
      <td>15.96%</td>
      <td>84.33</td>
      <td>C</td>
      <td>C5</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1076863</td>
      <td>1277178</td>
      <td>10000</td>
      <td>10000</td>
      <td>10000.0</td>
      <td>36 months</td>
      <td>13.49%</td>
      <td>339.31</td>
      <td>C</td>
      <td>C1</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1075358</td>
      <td>1311748</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000.0</td>
      <td>60 months</td>
      <td>12.69%</td>
      <td>67.79</td>
      <td>B</td>
      <td>B5</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 111 columns</p>
</div>




```python
loan_data.shape
```




    (39717, 111)




```python
loan_data.isnull().sum()
```




    id                                0
    member_id                         0
    loan_amnt                         0
    funded_amnt                       0
    funded_amnt_inv                   0
                                  ...  
    tax_liens                        39
    tot_hi_cred_lim               39717
    total_bal_ex_mort             39717
    total_bc_limit                39717
    total_il_high_credit_limit    39717
    Length: 111, dtype: int64



### Many columns contain exclusively null values. Let's eliminate these columns to streamline the dataset.


```python
loan_data.dropna(axis = 1, how = 'all', inplace = True)
loan_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>member_id</th>
      <th>loan_amnt</th>
      <th>funded_amnt</th>
      <th>funded_amnt_inv</th>
      <th>term</th>
      <th>int_rate</th>
      <th>installment</th>
      <th>grade</th>
      <th>sub_grade</th>
      <th>...</th>
      <th>next_pymnt_d</th>
      <th>last_credit_pull_d</th>
      <th>collections_12_mths_ex_med</th>
      <th>policy_code</th>
      <th>application_type</th>
      <th>acc_now_delinq</th>
      <th>chargeoff_within_12_mths</th>
      <th>delinq_amnt</th>
      <th>pub_rec_bankruptcies</th>
      <th>tax_liens</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1077501</td>
      <td>1296599</td>
      <td>5000</td>
      <td>5000</td>
      <td>4975.0</td>
      <td>36 months</td>
      <td>10.65%</td>
      <td>162.87</td>
      <td>B</td>
      <td>B2</td>
      <td>...</td>
      <td>NaN</td>
      <td>May-16</td>
      <td>0.0</td>
      <td>1</td>
      <td>INDIVIDUAL</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1077430</td>
      <td>1314167</td>
      <td>2500</td>
      <td>2500</td>
      <td>2500.0</td>
      <td>60 months</td>
      <td>15.27%</td>
      <td>59.83</td>
      <td>C</td>
      <td>C4</td>
      <td>...</td>
      <td>NaN</td>
      <td>Sep-13</td>
      <td>0.0</td>
      <td>1</td>
      <td>INDIVIDUAL</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1077175</td>
      <td>1313524</td>
      <td>2400</td>
      <td>2400</td>
      <td>2400.0</td>
      <td>36 months</td>
      <td>15.96%</td>
      <td>84.33</td>
      <td>C</td>
      <td>C5</td>
      <td>...</td>
      <td>NaN</td>
      <td>May-16</td>
      <td>0.0</td>
      <td>1</td>
      <td>INDIVIDUAL</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1076863</td>
      <td>1277178</td>
      <td>10000</td>
      <td>10000</td>
      <td>10000.0</td>
      <td>36 months</td>
      <td>13.49%</td>
      <td>339.31</td>
      <td>C</td>
      <td>C1</td>
      <td>...</td>
      <td>NaN</td>
      <td>Apr-16</td>
      <td>0.0</td>
      <td>1</td>
      <td>INDIVIDUAL</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1075358</td>
      <td>1311748</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000.0</td>
      <td>60 months</td>
      <td>12.69%</td>
      <td>67.79</td>
      <td>B</td>
      <td>B5</td>
      <td>...</td>
      <td>Jun-16</td>
      <td>May-16</td>
      <td>0.0</td>
      <td>1</td>
      <td>INDIVIDUAL</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 57 columns</p>
</div>



   ##There are several columns which are single valued.
   ## They cannot contribute to our analysis in any way. So removing them.


```python
loan_data.drop(['pymnt_plan', "initial_list_status",'collections_12_mths_ex_med','policy_code','acc_now_delinq', 'application_type', 'pub_rec_bankruptcies', 'tax_liens', 'delinq_amnt'], axis = 1, inplace = True)
loan_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>member_id</th>
      <th>loan_amnt</th>
      <th>funded_amnt</th>
      <th>funded_amnt_inv</th>
      <th>term</th>
      <th>int_rate</th>
      <th>installment</th>
      <th>grade</th>
      <th>sub_grade</th>
      <th>...</th>
      <th>total_rec_prncp</th>
      <th>total_rec_int</th>
      <th>total_rec_late_fee</th>
      <th>recoveries</th>
      <th>collection_recovery_fee</th>
      <th>last_pymnt_d</th>
      <th>last_pymnt_amnt</th>
      <th>next_pymnt_d</th>
      <th>last_credit_pull_d</th>
      <th>chargeoff_within_12_mths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1077501</td>
      <td>1296599</td>
      <td>5000</td>
      <td>5000</td>
      <td>4975.0</td>
      <td>36 months</td>
      <td>10.65%</td>
      <td>162.87</td>
      <td>B</td>
      <td>B2</td>
      <td>...</td>
      <td>5000.00</td>
      <td>863.16</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>Jan-15</td>
      <td>171.62</td>
      <td>NaN</td>
      <td>May-16</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1077430</td>
      <td>1314167</td>
      <td>2500</td>
      <td>2500</td>
      <td>2500.0</td>
      <td>60 months</td>
      <td>15.27%</td>
      <td>59.83</td>
      <td>C</td>
      <td>C4</td>
      <td>...</td>
      <td>456.46</td>
      <td>435.17</td>
      <td>0.00</td>
      <td>117.08</td>
      <td>1.11</td>
      <td>Apr-13</td>
      <td>119.66</td>
      <td>NaN</td>
      <td>Sep-13</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1077175</td>
      <td>1313524</td>
      <td>2400</td>
      <td>2400</td>
      <td>2400.0</td>
      <td>36 months</td>
      <td>15.96%</td>
      <td>84.33</td>
      <td>C</td>
      <td>C5</td>
      <td>...</td>
      <td>2400.00</td>
      <td>605.67</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>Jun-14</td>
      <td>649.91</td>
      <td>NaN</td>
      <td>May-16</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1076863</td>
      <td>1277178</td>
      <td>10000</td>
      <td>10000</td>
      <td>10000.0</td>
      <td>36 months</td>
      <td>13.49%</td>
      <td>339.31</td>
      <td>C</td>
      <td>C1</td>
      <td>...</td>
      <td>10000.00</td>
      <td>2214.92</td>
      <td>16.97</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>Jan-15</td>
      <td>357.48</td>
      <td>NaN</td>
      <td>Apr-16</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1075358</td>
      <td>1311748</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000.0</td>
      <td>60 months</td>
      <td>12.69%</td>
      <td>67.79</td>
      <td>B</td>
      <td>B5</td>
      <td>...</td>
      <td>2475.94</td>
      <td>1037.39</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>May-16</td>
      <td>67.79</td>
      <td>Jun-16</td>
      <td>May-16</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 48 columns</p>
</div>



####  To refine the dataset by eliminating irrelevant and redundant features for effective predictive modeling of loan default.

Feature Identification and Removal
Post-approval features: Columns reflecting loan performance post-disbursement (e.g., payment history, recovery status) will be excluded as they are not available at the time of credit decisioning.
Identifier and descriptive features: Columns serving as unique identifiers (e.g., 'id', 'member_id'), textual descriptions (e.g., 'title', 'desc', 'emp_title'), and geographic indicators (e.g., 'zip_code', 'addr_state') will be removed due to their lack of predictive power in the context of loan default.
Redundant features: The column 'funded_amnt' will be dropped as it is superseded by 'funded_amnt_inv' which provides equivalent information.
Identified Post-Approval Features
The following columns are identified as post-approval metrics:

delinq_2yrs: Number of delinquencies in the past 2 years
revol_bal: Revolving balance
out_prncp: Outstanding principal
total_pymnt: Total payment received
total_rec_prncp: Total received principal
total_rec_int: Total received interest
total_rec_late_fee: Total received late fees
recoveries: Recoveries
collection_recovery_fee: Collection recovery fee
last_pymnt_d: Last payment date
last_pymnt_amnt: Last payment amount
next_pymnt_d: Next payment date
chargeoff_within_12_mths: Charged off within 12 months
mths_since_last_delinq: Months since last delinquency
mths_since_last_record: Months since last record



```python
loan_data.drop(["id", "member_id", "url", "title", "emp_title", "zip_code", "last_credit_pull_d", "addr_state","desc","out_prncp_inv","total_pymnt_inv","funded_amnt", "delinq_2yrs", "revol_bal", "out_prncp", "total_pymnt", "total_rec_prncp", "total_rec_int", "total_rec_late_fee", "recoveries", "collection_recovery_fee", "last_pymnt_d", "last_pymnt_amnt", "next_pymnt_d" , "chargeoff_within_12_mths", "mths_since_last_delinq", "mths_since_last_record"], axis = 1, inplace = True)
```

loan_data.shape


```python
loan_data.columns
```




    Index(['loan_amnt', 'funded_amnt_inv', 'term', 'int_rate', 'installment',
           'grade', 'sub_grade', 'emp_length', 'home_ownership', 'annual_inc',
           'verification_status', 'issue_d', 'loan_status', 'purpose', 'dti',
           'earliest_cr_line', 'inq_last_6mths', 'open_acc', 'pub_rec',
           'revol_util', 'total_acc'],
          dtype='object')



##To accurately predict loan default, the analysis requires a dataset of completed loan cycles. 
##Therefore, records with a 'Current' loan status will be excluded as they represent ongoing loans without definitive outcomes.
## This ensures that the modeling process is based solely on instances where the borrower's repayment behavior is fully observed.


```python
loan_data = loan_data[loan_data.loan_status != "Current"]
loan_data.loan_status.unique()
```




    array(['Fully Paid', 'Charged Off'], dtype=object)




```python
Checking for missing values

```


```python
(loan_data.isna().sum()/len(loan_data.index))*100
```




    id                              0.000000
    member_id                       0.000000
    loan_amnt                       0.000000
    funded_amnt                     0.000000
    funded_amnt_inv                 0.000000
                                     ...    
    tax_liens                       0.098195
    tot_hi_cred_lim               100.000000
    total_bal_ex_mort             100.000000
    total_bc_limit                100.000000
    total_il_high_credit_limit    100.000000
    Length: 111, dtype: float64




```python
loan_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 38577 entries, 0 to 39716
    Data columns (total 21 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   loan_amnt            38577 non-null  int64  
     1   funded_amnt_inv      38577 non-null  float64
     2   term                 38577 non-null  object 
     3   int_rate             38577 non-null  object 
     4   installment          38577 non-null  float64
     5   grade                38577 non-null  object 
     6   sub_grade            38577 non-null  object 
     7   emp_length           37544 non-null  object 
     8   home_ownership       38577 non-null  object 
     9   annual_inc           38577 non-null  float64
     10  verification_status  38577 non-null  object 
     11  issue_d              38577 non-null  object 
     12  loan_status          38577 non-null  object 
     13  purpose              38577 non-null  object 
     14  dti                  38577 non-null  float64
     15  earliest_cr_line     38577 non-null  object 
     16  inq_last_6mths       38577 non-null  int64  
     17  open_acc             38577 non-null  int64  
     18  pub_rec              38577 non-null  int64  
     19  revol_util           38527 non-null  object 
     20  total_acc            38577 non-null  int64  
    dtypes: float64(4), int64(5), object(12)
    memory usage: 6.5+ MB
    


```python
print("Mode : " + loan_data.emp_length.mode()[0])
loan_data.emp_length.value_counts()
```

    Mode : 10+ years
    




    emp_length
    10+ years    8879
    < 1 year     4583
    2 years      4388
    3 years      4095
    4 years      3436
    5 years      3282
    1 year       3240
    6 years      2229
    7 years      1773
    8 years      1479
    9 years      1258
    Name: count, dtype: int64




```python
loan_data.emp_length.fillna(loan_data.emp_length.mode()[0], inplace = True)
loan_data.emp_length.isna().sum()
```




    0




```python
loan_data.dropna(axis = 0, subset = ['revol_util'] , inplace = True)
loan_data.revol_util.isna().sum()
```




    0


Standardizing the data
"revol_util" column although described as an object column, it has continous values.
So we need to standardize the data in this column
"int_rate" is one such column.
"emp_length" --> { (< 1 year) is assumed as 0 and 10+ years is assumed as 10 }
Although the datatype of "term" is arguable to be an integer, there are only two values in the whole column and it might as well be declared a categorical variable.

```python
loan_data.revol_util = pd.to_numeric(loan_data.revol_util.apply(lambda x : x.split('%')[0]))
```


```python
loan_data.int_rate = pd.to_numeric(loan_data.int_rate.apply(lambda x : x.split('%')[0]))
```


```python
loan_data.emp_length = pd.to_numeric(loan_data.emp_length.apply(lambda x: 0 if "<" in x else (x.split('+')[0] if "+" in x else x.split()[0])))
```


```python
loan_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_amnt</th>
      <th>funded_amnt_inv</th>
      <th>term</th>
      <th>int_rate</th>
      <th>installment</th>
      <th>grade</th>
      <th>sub_grade</th>
      <th>emp_length</th>
      <th>home_ownership</th>
      <th>annual_inc</th>
      <th>...</th>
      <th>issue_d</th>
      <th>loan_status</th>
      <th>purpose</th>
      <th>dti</th>
      <th>earliest_cr_line</th>
      <th>inq_last_6mths</th>
      <th>open_acc</th>
      <th>pub_rec</th>
      <th>revol_util</th>
      <th>total_acc</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000</td>
      <td>4975.0</td>
      <td>36 months</td>
      <td>10.65</td>
      <td>162.87</td>
      <td>B</td>
      <td>B2</td>
      <td>10</td>
      <td>RENT</td>
      <td>24000.0</td>
      <td>...</td>
      <td>Dec-11</td>
      <td>Fully Paid</td>
      <td>credit_card</td>
      <td>27.65</td>
      <td>Jan-85</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>83.7</td>
      <td>9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2500</td>
      <td>2500.0</td>
      <td>60 months</td>
      <td>15.27</td>
      <td>59.83</td>
      <td>C</td>
      <td>C4</td>
      <td>0</td>
      <td>RENT</td>
      <td>30000.0</td>
      <td>...</td>
      <td>Dec-11</td>
      <td>Charged Off</td>
      <td>car</td>
      <td>1.00</td>
      <td>Apr-99</td>
      <td>5</td>
      <td>3</td>
      <td>0</td>
      <td>9.4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2400</td>
      <td>2400.0</td>
      <td>36 months</td>
      <td>15.96</td>
      <td>84.33</td>
      <td>C</td>
      <td>C5</td>
      <td>10</td>
      <td>RENT</td>
      <td>12252.0</td>
      <td>...</td>
      <td>Dec-11</td>
      <td>Fully Paid</td>
      <td>small_business</td>
      <td>8.72</td>
      <td>Nov-01</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>98.5</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10000</td>
      <td>10000.0</td>
      <td>36 months</td>
      <td>13.49</td>
      <td>339.31</td>
      <td>C</td>
      <td>C1</td>
      <td>10</td>
      <td>RENT</td>
      <td>49200.0</td>
      <td>...</td>
      <td>Dec-11</td>
      <td>Fully Paid</td>
      <td>other</td>
      <td>20.00</td>
      <td>Feb-96</td>
      <td>1</td>
      <td>10</td>
      <td>0</td>
      <td>21.0</td>
      <td>37</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5000</td>
      <td>5000.0</td>
      <td>36 months</td>
      <td>7.90</td>
      <td>156.46</td>
      <td>A</td>
      <td>A4</td>
      <td>3</td>
      <td>RENT</td>
      <td>36000.0</td>
      <td>...</td>
      <td>Dec-11</td>
      <td>Fully Paid</td>
      <td>wedding</td>
      <td>11.20</td>
      <td>Nov-04</td>
      <td>3</td>
      <td>9</td>
      <td>0</td>
      <td>28.3</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
file_path = 'C:\\Users\\GNQTB\\DocumentsP\\Python\\loan.csv'
loan_data = pd.read_csv(file_path)

sns.boxplot(loan_data['annual_inc'])
```




    <Axes: >




    
![png](output_26_1.png)
    



```python
quantile_info = loan_data.annual_inc.quantile([0.5, 0.75,0.90, 0.95, 0.97,0.98, 0.99])
quantile_info
```




    0.50     59000.0
    0.75     82000.0
    0.90    115000.0
    0.95    140004.0
    0.97    165000.0
    0.98    187000.0
    0.99    234000.0
    Name: annual_inc, dtype: float64




```python
per_95_annual_inc = loan_data['annual_inc'].quantile(0.95)
loan_data = loan_data[loan_data.annual_inc <= per_95_annual_inc]
```


```python
sns.boxplot(loan_data.annual_inc)
```




    <Axes: >




    
![png](output_29_1.png)
    



```python
sns.boxplot(loan_data.dti)
```




    <Axes: >




    
![png](output_30_1.png)
    



```python
sns.boxplot(loan_data.loan_amnt)
```




    <Axes: >




    
![png](output_31_1.png)
    



```python
loan_data.loan_amnt.quantile([0.75,0.90,0.95,0.97,0.975, 0.98, 0.99, 1.0])
```




    0.750    15000.0
    0.900    20000.0
    0.950    25000.0
    0.970    25475.0
    0.975    28000.0
    0.980    30000.0
    0.990    35000.0
    1.000    35000.0
    Name: loan_amnt, dtype: float64




```python
sns.boxplot(loan_data.funded_amnt_inv)
```




    <Axes: >




    
![png](output_33_1.png)
    



```python
loan_data.funded_amnt_inv.quantile([0.5,0.75,0.90,0.95,0.97,0.975, 0.98,0.985, 0.99, 1.0])
```




    0.500     8396.342174
    0.750    13649.999283
    0.900    19750.000000
    0.950    23949.287805
    0.970    24975.000000
    0.975    25350.000000
    0.980    27953.287538
    0.985    29925.000000
    0.990    31966.803281
    1.000    35000.000000
    Name: funded_amnt_inv, dtype: float64




```python
sns.countplot(x = 'loan_status', data = loan_data)
```




    <Axes: xlabel='loan_status', ylabel='count'>




    
![png](output_35_1.png)
    



```python
loan_data.sub_grade = pd.to_numeric(loan_data.sub_grade.apply(lambda x : x[-1]))
loan_data.sub_grade.head()
```




    0    2
    1    4
    2    5
    3    1
    5    4
    Name: sub_grade, dtype: int64




```python
fig, ax = plt.subplots(figsize=(12,7))
sns.set_palette('colorblind')
sns.countplot(x = 'grade', order = ['A', 'B', 'C', 'D', 'E', 'F', 'G'] , hue = 'sub_grade',data = loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='grade', ylabel='count'>




    
![png](output_37_1.png)
    



```python
sns.countplot(x = 'grade', data = loan_data[loan_data.loan_status == 'Charged Off'], order = ['A', 'B', 'C', 'D', 'E', 'F', 'G'])
```




    <Axes: xlabel='grade', ylabel='count'>




    
![png](output_38_1.png)
    



```python
#checking unique values for home_ownership
loan_data['home_ownership'].unique()
```




    array(['RENT', 'OWN', 'MORTGAGE', 'OTHER', 'NONE'], dtype=object)




```python
There are only 3 records with 'NONE' value in the data. So replacing the value with 'OTHER'
```


```python
#replacing 'NONE' with 'OTHERS'
loan_data['home_ownership'].replace(to_replace = ['NONE'],value='OTHER',inplace = True)

```


```python
#checking unique values for home_ownership again
loan_data['home_ownership'].unique()
```




    array(['RENT', 'OWN', 'MORTGAGE', 'OTHER'], dtype=object)




```python
fig, ax = plt.subplots(figsize = (6,4))
ax.set(yscale = 'log')
sns.countplot(x='home_ownership', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='home_ownership', ylabel='count'>




    
![png](output_43_1.png)
    



```python
fig, ax = plt.subplots(figsize = (12,8))
ax.set(xscale = 'log')
sns.countplot(y ='purpose', data=loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='count', ylabel='purpose'>




    
![png](output_44_1.png)
    



```python
#creating bins for int_rate,open_acc,revol_util,total_acc
loan_data['int_rate_groups'] = pd.cut(loan_data['int_rate'], bins=5,precision =0,labels=['5%-9%','9%-13%','13%-17%','17%-21%','21%-24%'])
loan_data['open_acc_groups'] = pd.cut(loan_data['open_acc'],bins = 5,precision =0,labels=['2-10','10-19','19-27','27-36','36-44'])
loan_data['revol_util_groups'] = pd.cut(loan_data['revol_util'], bins=5,precision =0,labels=['0-20','20-40','40-60','60-80','80-100'])
loan_data['total_acc_groups'] = pd.cut(loan_data['total_acc'], bins=5,precision =0,labels=['2-20','20-37','37-55','55-74','74-90'])
loan_data['annual_inc_groups'] = pd.cut(loan_data['annual_inc'], bins=5,precision =0,labels =['3k-31k','31k-58k','58k-85k','85k-112k','112k-140k'])
```


```python
# Viewing new bins created
loan_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_amnt</th>
      <th>funded_amnt_inv</th>
      <th>term</th>
      <th>int_rate</th>
      <th>installment</th>
      <th>grade</th>
      <th>sub_grade</th>
      <th>emp_length</th>
      <th>home_ownership</th>
      <th>annual_inc</th>
      <th>...</th>
      <th>inq_last_6mths</th>
      <th>open_acc</th>
      <th>pub_rec</th>
      <th>revol_util</th>
      <th>total_acc</th>
      <th>int_rate_groups</th>
      <th>open_acc_groups</th>
      <th>revol_util_groups</th>
      <th>total_acc_groups</th>
      <th>annual_inc_groups</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000</td>
      <td>4975.0</td>
      <td>36 months</td>
      <td>10.65</td>
      <td>162.87</td>
      <td>B</td>
      <td>2</td>
      <td>10</td>
      <td>RENT</td>
      <td>24000.0</td>
      <td>...</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>83.7</td>
      <td>9</td>
      <td>9%-13%</td>
      <td>2-10</td>
      <td>80-100</td>
      <td>2-20</td>
      <td>3k-31k</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2500</td>
      <td>2500.0</td>
      <td>60 months</td>
      <td>15.27</td>
      <td>59.83</td>
      <td>C</td>
      <td>4</td>
      <td>0</td>
      <td>RENT</td>
      <td>30000.0</td>
      <td>...</td>
      <td>5</td>
      <td>3</td>
      <td>0</td>
      <td>9.4</td>
      <td>4</td>
      <td>13%-17%</td>
      <td>2-10</td>
      <td>0-20</td>
      <td>2-20</td>
      <td>3k-31k</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2400</td>
      <td>2400.0</td>
      <td>36 months</td>
      <td>15.96</td>
      <td>84.33</td>
      <td>C</td>
      <td>5</td>
      <td>10</td>
      <td>RENT</td>
      <td>12252.0</td>
      <td>...</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>98.5</td>
      <td>10</td>
      <td>13%-17%</td>
      <td>2-10</td>
      <td>80-100</td>
      <td>2-20</td>
      <td>3k-31k</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10000</td>
      <td>10000.0</td>
      <td>36 months</td>
      <td>13.49</td>
      <td>339.31</td>
      <td>C</td>
      <td>1</td>
      <td>10</td>
      <td>RENT</td>
      <td>49200.0</td>
      <td>...</td>
      <td>1</td>
      <td>10</td>
      <td>0</td>
      <td>21.0</td>
      <td>37</td>
      <td>13%-17%</td>
      <td>2-10</td>
      <td>20-40</td>
      <td>20-37</td>
      <td>31k-58k</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5000</td>
      <td>5000.0</td>
      <td>36 months</td>
      <td>7.90</td>
      <td>156.46</td>
      <td>A</td>
      <td>4</td>
      <td>3</td>
      <td>RENT</td>
      <td>36000.0</td>
      <td>...</td>
      <td>3</td>
      <td>9</td>
      <td>0</td>
      <td>28.3</td>
      <td>12</td>
      <td>5%-9%</td>
      <td>2-10</td>
      <td>20-40</td>
      <td>2-20</td>
      <td>31k-58k</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
fig, ax = plt.subplots(figsize = (15,10))
plt.subplot(221)
sns.countplot(x='int_rate_groups', data=loan_data[loan_data.loan_status == 'Charged Off'])
plt.xlabel('Interest Rate')
plt.subplot(222)
sns.countplot(x='emp_length', data=loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='emp_length', ylabel='count'>




    
![png](output_47_1.png)
    



```python
fig, ax = plt.subplots(figsize = (7,5))
ax.set_yscale('log')
sns.countplot(x='open_acc_groups', data=loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='open_acc_groups', ylabel='count'>




    
![png](output_48_1.png)
    



```python
sns.countplot(x='revol_util_groups', data=loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='revol_util_groups', ylabel='count'>




    
![png](output_49_1.png)
    



```python
fig, ax = plt.subplots(figsize = (8,6))
ax.set_yscale('log')
sns.countplot(x='total_acc_groups', data=loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='total_acc_groups', ylabel='count'>




    
![png](output_50_1.png)
    



```python
fig, ax = plt.subplots(figsize = (10,6))
sns.countplot(x='annual_inc_groups', data=loan_data[loan_data.loan_status == 'Charged Off'])
```




    <Axes: xlabel='annual_inc_groups', ylabel='count'>




    
![png](output_51_1.png)
    



```python
sns.countplot(x='verification_status', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='verification_status', ylabel='count'>




    
![png](output_52_1.png)
    



```python
sns.countplot(y='term', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='count', ylabel='term'>




    
![png](output_53_1.png)
    



```python
fig,ax = plt.subplots(figsize = (10,8))
ax.set_yscale('log')
sns.countplot(x='inq_last_6mths', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='inq_last_6mths', ylabel='count'>




    
![png](output_54_1.png)
    



```python
fig,ax = plt.subplots(figsize = (7,5))
ax.set_yscale('log')
sns.countplot(x='pub_rec', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='pub_rec', ylabel='count'>




    
![png](output_55_1.png)
    



```python
## Extracting month and year
df_month_year = loan_data['issue_d'].str.partition("-", True)     
loan_data['issue_month']=df_month_year[0]                       
loan_data['issue_year']='20' + df_month_year[2]
```


```python
loan_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>member_id</th>
      <th>loan_amnt</th>
      <th>funded_amnt</th>
      <th>funded_amnt_inv</th>
      <th>term</th>
      <th>int_rate</th>
      <th>installment</th>
      <th>grade</th>
      <th>sub_grade</th>
      <th>...</th>
      <th>pct_tl_nvr_dlq</th>
      <th>percent_bc_gt_75</th>
      <th>pub_rec_bankruptcies</th>
      <th>tax_liens</th>
      <th>tot_hi_cred_lim</th>
      <th>total_bal_ex_mort</th>
      <th>total_bc_limit</th>
      <th>total_il_high_credit_limit</th>
      <th>issue_month</th>
      <th>issue_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1077501</td>
      <td>1296599</td>
      <td>5000</td>
      <td>5000</td>
      <td>4975.0</td>
      <td>36 months</td>
      <td>10.65%</td>
      <td>162.87</td>
      <td>B</td>
      <td>B2</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Dec</td>
      <td>2011</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1077430</td>
      <td>1314167</td>
      <td>2500</td>
      <td>2500</td>
      <td>2500.0</td>
      <td>60 months</td>
      <td>15.27%</td>
      <td>59.83</td>
      <td>C</td>
      <td>C4</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Dec</td>
      <td>2011</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1077175</td>
      <td>1313524</td>
      <td>2400</td>
      <td>2400</td>
      <td>2400.0</td>
      <td>36 months</td>
      <td>15.96%</td>
      <td>84.33</td>
      <td>C</td>
      <td>C5</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Dec</td>
      <td>2011</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1076863</td>
      <td>1277178</td>
      <td>10000</td>
      <td>10000</td>
      <td>10000.0</td>
      <td>36 months</td>
      <td>13.49%</td>
      <td>339.31</td>
      <td>C</td>
      <td>C1</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Dec</td>
      <td>2011</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1075358</td>
      <td>1311748</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000.0</td>
      <td>60 months</td>
      <td>12.69%</td>
      <td>67.79</td>
      <td>B</td>
      <td>B5</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Dec</td>
      <td>2011</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 113 columns</p>
</div>




```python
plt.figure(figsize=(15,15))
plt.subplot(221)
sns.countplot(x='issue_month', data=loan_data[loan_data['loan_status']=='Charged Off'])
plt.subplot(222)
sns.countplot(x='issue_year', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='issue_year', ylabel='count'>




    
![png](output_58_1.png)
    



```python

```


```python
fig,ax = plt.subplots(figsize = (12,5))
ax.set_yscale('log')
sns.countplot(x='funded_amnt_inv_group', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='funded_amnt_inv_group', ylabel='count'>




    
![png](output_60_1.png)
    



```python
fig,ax = plt.subplots(figsize = (15,6))
ax.set_yscale('log')
sns.countplot(x='loan_amnt_groups', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='loan_amnt_groups', ylabel='count'>




    
![png](output_61_1.png)
    



```python
sns.countplot(x='dti_groups', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='dti_groups', ylabel='count'>




    
![png](output_62_1.png)
    



```python
fig,ax = plt.subplots(figsize = (15,6))
ax.set_yscale('log')
sns.countplot(x='installment_groups', data=loan_data[loan_data['loan_status']=='Charged Off'])
```




    <Axes: xlabel='installment_groups', ylabel='count'>




    
![png](output_63_1.png)
    



```python
# Summary of Key Factors Influencing Loan Default

# Financial Situation: Lower income, high debt-to-income ratio, and a history of missed payments are associated with increased default risk.
# Loan Characteristics: Loans with longer terms, higher interest rates, and larger amounts are more likely to result in default.
# Borrower Behavior: Renters, individuals using loans for debt consolidation, and those with multiple open credit accounts are at a higher risk of default.
# Credit History: A lack of credit inquiries and a clean public record, while seemingly positive, might paradoxically indicate a higher risk. This could be due to factors such as limited credit history or potential over-reliance on credit.
# Loan Grade: Loans categorized as 'B' with a sub-grade of 'B5' are associated with a higher default rate.

# These factors suggest that borrowers with financial strain, poor credit management habits, and a reliance on loans for immediate financial relief are more likely to encounter difficulties in repaying their debts.
```


```python
# Annual income vs loan purpose
```


```python
plt.figure(figsize=(10,10))
sns.barplot(data =loan_data,x='loan_amnt', y='grade', hue ='loan_status',palette="pastel", order=['A','B','C','D','E','F','G'])
plt.show()
```


    
![png](output_66_0.png)
    



```python
plt.figure(figsize=(20,20))
plt.subplot(221)
sns.barplot(data =loan_data,y='loan_amnt', x='emp_length', hue ='loan_status',palette="pastel")
plt.subplot(222)
sns.barplot(data =loan_data,y='loan_amnt', x='verification_status', hue ='loan_status',palette="pastel")
```




    <Axes: xlabel='verification_status', ylabel='loan_amnt'>




    
![png](output_67_1.png)
    



```python
grade vs interest rate
```


```python
plt.figure(figsize=(10,10))
sns.barplot(data =loan_data,x='int_rate', y='grade', hue ='loan_status',palette="pastel", order=['A','B','C','D','E','F','G'])
plt.show()
```


    
![png](output_69_0.png)
    



```python
# fig,ax = plt.subplots(figsize = (15,6))
plt.tight_layout()
sns.catplot(data =loan_data,y ='int_rate', x ='loan_amnt_groups', hue ='loan_status',palette="pastel",kind = 'box')
```




    <seaborn.axisgrid.FacetGrid at 0x1e60787bcd0>




    <Figure size 640x480 with 0 Axes>



    
![png](output_70_2.png)
    



```python
# Observation: Interest rate for charged off loans is higher than fully paid loans across all loan_amount groups.
# This could be a strong indicator of loan default.
```

Findings
# Key Findings

# Income and Loan Purpose:
# - Home improvement loans for applicants earning 60-70k have a higher default rate.

# Income and Home Ownership:
# - Mortgage holders with income between 60-70k show a higher propensity to default.

# Income and Interest Rate:
# - Loans with interest rates in the 21-24% range for applicants earning 70-80k have a higher default risk.

# Loan Amount and Interest Rate:
# - Loans between 30k-35k with interest rates of 15-17.5% are associated with higher default rates.

# Loan Purpose and Amount:
# - Small business loans exceeding 14k have a higher default likelihood.

# Home Ownership and Loan Amount:
# - Mortgage holders with loans between 14-16k are more likely to default.

# Loan Grade and Amount:
# - Grade F loans between 15k-20k have a higher default risk.

# Employment Length and Loan Amount:
# - Individuals with 10 years of employment and loans between 12k-14k show a higher default tendency.

# Loan Verification and Amount:
# - Verified loans exceeding 16k have a higher default probability.

# Loan Grade and Interest Rate:
# - Grade G loans with interest rates above 20% are associated with higher default risk.